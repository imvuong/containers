<?php

namespace CirrusSearch\Search;

/**
 * Index field representing integer.
 * @package CirrusSearch
 */
class IntegerIndexField extends CirrusIndexField {
	protected $typeName = 'long';
}
